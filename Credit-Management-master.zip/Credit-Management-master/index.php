<!DOCTYPE html>
<html>
<head>
	<title> Credit Management</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
<div id=ad>

<div id=he>
<h1>CREDIT MANAGEMENT</h1>
</div>
<div class="container" id=as>
<a class="btn btn-success" type="button" value="View all users" href="table.php">VIEW ALL USERS</a>
</div>
</div>
</body>
</html>
